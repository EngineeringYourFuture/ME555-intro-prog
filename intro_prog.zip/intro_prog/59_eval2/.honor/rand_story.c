#include "rand_story.h"
