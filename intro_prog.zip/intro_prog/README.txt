Welcome to your intro_prog git repository.

The first thing you should do is 

git pull

Once you have done that, you will see your initial assignments. As you
complete assignments, more will be released. 

You should start with 00_submit, which will help you familiarize yourself
with git, view-grades, and grade.
