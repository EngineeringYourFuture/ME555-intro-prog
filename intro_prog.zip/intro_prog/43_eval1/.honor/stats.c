#include "stats.h"

// any other headers you need here

player_t parseLine(char * line) {
  // STEP 1: write me
  player_t answer;
  return answer;
}

void addGame(player_t * roster,
             size_t n_players,
             unsigned number,
             unsigned rebounds,
             unsigned points) {
  // STEP 2: write me
}

void printDoubleDouble(player_t * roster, size_t n_players) {
  // STEP 3: write me
}

void printPosPoints(player_t * roster, size_t n_players) {
  // STEP 4: write me
}
