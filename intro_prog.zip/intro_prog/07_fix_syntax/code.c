//line 1
int f(int x) {                   //line 2
  int answer = 0;                //line 3
  for (int i = 0; i < x; i++) {  //line 4
    answer += i * i;             //line 5
  }                              //line 6
  return answer;                 //line 7
}  //line 8
