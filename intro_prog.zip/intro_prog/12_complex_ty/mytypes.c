struct _complex_num_t {
  double real_part;
  double imaginary_part;
};
typedef struct _complex_num_t complex_num_t;

enum _animal_t { CAT, FISH, SNAKE, DOG, HORSE };
typedef enum _animal_t animal_t;
